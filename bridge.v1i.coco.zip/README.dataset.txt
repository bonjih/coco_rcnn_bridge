# bridge > 2024-04-23 3:54pm
https://universe.roboflow.com/jcu-huzz4/bridge-km1qr

Provided by a Roboflow user
License: Public Domain

